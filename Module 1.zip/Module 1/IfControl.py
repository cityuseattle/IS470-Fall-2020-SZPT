
print('How old are you')
age = int (input())

if age < 22:
    print('you are too young to have a drink.')
elif age >=80:
    print( 'ok, you will get a free drink')
else:
    print('sure, enjoy your drink')
