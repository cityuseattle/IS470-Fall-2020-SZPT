price = 10
print('How many beers you want?')
print('Your total price is: $'+ str(price * int(input())))