print("\nMultiple assignments\n")
a,b,c = 5, 3.2, "Hello"
print ("a = ",a)
print ("b = " ,b)
print ("c = ",c)

x = y = z = "Python"
print ("x = "+x)
print ("y = "+y)
print ("z = "+z)
