message="Hello World"
print (message)
message = 5
print(message)
