print("\nFloat\n")
a=2.2
b=2
c=0.1
print("a + b = ",a+b)
print("a + c = ",a+c)
print("a * b = ",a*b)
print("a ** b = ",a ** b)
