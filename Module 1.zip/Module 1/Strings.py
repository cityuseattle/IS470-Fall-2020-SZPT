message = " this is also a string"
print("Title: "+ message.title())

print ("Uppercase :"+message.upper())

print("Lowercase :"+message.lower())

first_message = "Hi !"
second_message = "How are you ?"
full_message = f"{first_message} {second_message}"
print (full_message)
