courses = ('CS101', 2.0 ,3)
courses[1] = 4.0

